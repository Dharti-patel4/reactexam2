import React from 'react'

const About = () => {
  return (
    <div>
    <h1>About Us</h1>
      <p>As you’ll soon see, some businesses devote one or two short paragraphs to their About page – and that’s it. Others tell a long story of how they were founded, and yet more have multiple pages within their About page wheelhouse. 

</p>
    </div>
  )
}

export default About
