import React from 'react'

const Add = () => {
  return (
    <div>

    <form>
        <input type='text' placeholder=''/>
        <input type='' placeholder=''/>
        </form>
      
    </div>
  )
}

export default Add
