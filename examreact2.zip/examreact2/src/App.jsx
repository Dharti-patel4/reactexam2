
import Allroutes from '../Route/Allroutes'
import './App.css'
import Navbar from './Compoents/Navbar'

function App() {
  

  return (
    <>
    
    <Navbar/>
    <Allroutes/>
    </>
  )
}

export default App